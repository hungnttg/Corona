/**
	Base class for all drawable objects, makes ordering automatic.
	@author Mac
*/

Framework.Drawable = function() {
    this.ZOrder = 0;
};

Framework.Drawable.prototype = {
    Draw: function(context) { }
};