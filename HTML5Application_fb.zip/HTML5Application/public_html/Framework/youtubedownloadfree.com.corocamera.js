/**
	Represents a camera used to offset drawing of sprites in the world.
	@author Mac
*/

Framework.Camera = function() {
	this.X = 0;
	this.Y = 0;
};