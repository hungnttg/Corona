/**
	Define the Framework namespace and any other miscellaneous setup.
	@author Mac
*/

var Framework = {};