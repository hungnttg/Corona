/**
	Represents a simple static sprite.
	@author Mac
*/

Framework.Sprite = function() {
	this.X = 0;
	this.Y = 0;
	this.Image = null;
};

Framework.Sprite.prototype = new Framework.Drawable();

Framework.Sprite.prototype.Draw = function(context, camera) {
	context.drawImage(this.Image, this.X - camera.X, this.Y - camera.Y);
};