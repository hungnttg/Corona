/**
	Simple demo of the engine.
	@author may Mac cua toi
*/

Framework.Application = function() {
    this.canvas = null;
    this.timer = null;
    this.stateContext = null;
};

Framework.Application.prototype = {
    Update: function(delta) {
        
        this.stateContext.Update(delta);
        
        this.canvas.BeginDraw();
        
        this.stateContext.Draw(this.canvas.BackBufferContext2D);
        
        this.canvas.EndDraw();
    },
    
    Initialize: function(defaultState, resWidth, resHeight) {
        this.canvas = new Framework.GameCanvas();
        this.timer = new Framework.GameTimer();
        Framework.KeyboardInput.Initialize();      
        this.canvas.Initialize("canvas", resWidth, resHeight);
        this.timer.UpdateObject = this;
        
        this.stateContext = new Framework.GameStateContext(defaultState);
        
        this.timer.Start();
    }
};