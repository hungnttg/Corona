/**
	Just create the global Mario object.
	@author Mac
*/

var Mario = {};